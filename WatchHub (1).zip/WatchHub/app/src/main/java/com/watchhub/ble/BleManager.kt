package com.watchhub.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.UUID

data class Found(val name: String, val address: String, val rssi: Int)

@SuppressLint("MissingPermission")
class BleManager(private val ctx: Context) : WatchIO {
    private val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var gatt: BluetoothGatt? = null
    private val drivers = listOf<WatchDriver>(MkWatchDriver())
    var driver: WatchDriver? = null; private set

    val found = MutableStateFlow<List<Found>>(emptyList())
    val connected = MutableStateFlow(false)
    val battery = MutableStateFlow<Int?>(null)

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(t: Int, r: ScanResult) {
            val n = r.device.name ?: return
            if (found.value.none { it.address == r.device.address })
                found.value = found.value + Found(n, r.device.address, r.rssi)
        }
    }
    fun startScan() { found.value = emptyList(); adapter.bluetoothLeScanner.startScan(scanCb) }
    fun stopScan() = adapter.bluetoothLeScanner.stopScan(scanCb)

    fun connect(address: String) {
        stopScan()
        val dev = adapter.getRemoteDevice(address)
        driver = drivers.firstOrNull { it.matches(dev.name) } ?: drivers.first()
        gatt = dev.connectGatt(ctx, true, object : BluetoothGattCallback() {   // autoConnect = auto-reconnect
            override fun onConnectionStateChange(g: BluetoothGatt, s: Int, n: Int) {
                connected.value = n == BluetoothProfile.STATE_CONNECTED
                if (connected.value) g.discoverServices()
            }
            override fun onServicesDiscovered(g: BluetoothGatt, s: Int) { driver?.onConnected(this@BleManager) }
            override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
                if (c.uuid.toString().startsWith("00002a19")) battery.value = c.value?.firstOrNull()?.toInt()?.and(0xFF)
            }
        })
    }
    fun disconnect() { gatt?.disconnect(); gatt?.close(); connected.value = false }

    override fun write(service: String, characteristic: String, data: ByteArray) {
        val c = gatt?.getService(UUID.fromString(service))?.getCharacteristic(UUID.fromString(characteristic)) ?: return
        c.value = data; gatt?.writeCharacteristic(c)
    }
    override fun read(service: String, characteristic: String) {
        gatt?.getService(UUID.fromString(service))?.getCharacteristic(UUID.fromString(characteristic))?.let { gatt?.readCharacteristic(it) }
    }
    fun pushMessage(app: String, title: String, text: String) { driver?.pushMessage(this, app, title, text) }
    fun setAlarm(id: Int, h: Int, m: Int, on: Boolean) { driver?.setAlarm(this, id, h, m, on) }
}
