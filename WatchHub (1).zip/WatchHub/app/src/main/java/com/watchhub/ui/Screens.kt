package com.watchhub.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.watchhub.App

private val Bg = Color(0xFF0B0B0D); private val Card = Color(0xFF1A1A1E)

@Composable fun WatchHubApp() {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Orange, background = Bg, surface = Card)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf("Watch" to Icons.Default.Watch, "Dials" to Icons.Default.Apps, "Alarm" to Icons.Default.Alarm, "Settings" to Icons.Default.Settings)
                    .forEachIndexed { i, (l, ic) -> NavigationBarItem(tab == i, { tab = i }, { Icon(ic, l) }, label = { Text(l) }) }
            } }) { p -> Box(Modifier.padding(p).fillMaxSize()) {
            when (tab) { 0 -> HomeScreen(); 1 -> MarketScreen(); 2 -> AlarmScreen(); else -> SettingsScreen() } } }
    }
}

@Composable fun HomeScreen() {
    val ble = App.ble; val connected by ble.connected.collectAsState(); val bat by ble.battery.collectAsState()
    val found by ble.found.collectAsState()
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item { UltraDial(bat, Modifier.fillMaxWidth(0.7f)) }
        item { Text(if (connected) "Connected • ${bat ?: "--"}%" else "Not connected", color = Color.White) }
        item { Button({ if (connected) ble.disconnect() else ble.startScan() }, Modifier.fillMaxWidth()) { Text(if (connected) "Disconnect" else "Scan for watch") } }
        items(found) { d ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(d.name, color = Color.White); Text(d.address, color = Color.Gray) }
                TextButton({ ble.connect(d.address) }) { Text("Connect") }
            }
        }
    }
}

data class Dial(val name: String, val tag: String)
@Composable fun MarketScreen() {
    val dials = remember { listOf(Dial("Ultra Orange", "Premium"), Dial("Titanium", "Premium"), Dial("Digital Neon", "Sport"), Dial("Classic", "Minimal"), Dial("Aqua Depth", "Dive"), Dial("Night Mode", "Dark")) }
    LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(dials) { d ->
            Column(Modifier.clip(RoundedCornerShape(20.dp)).background(Card).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                UltraDial(null, Modifier.fillMaxWidth()); Text(d.name, color = Color.White); Text(d.tag, color = Orange)
                Button({ /* TODO: dial upload via driver */ }) { Text("Install") }
            }
        }
    }
}

@Composable fun AlarmScreen() {
    var h by remember { mutableIntStateOf(7) }; var m by remember { mutableIntStateOf(0) }; var on by remember { mutableStateOf(false) }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Watch Alarm", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        Row { Slider(h.toFloat(), { h = it.toInt() }, valueRange = 0f..23f, modifier = Modifier.weight(1f)); Text("%02d".format(h), color = Color.White) }
        Row { Slider(m.toFloat(), { m = it.toInt() }, valueRange = 0f..59f, modifier = Modifier.weight(1f)); Text("%02d".format(m), color = Color.White) }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Enabled", color = Color.White, modifier = Modifier.weight(1f)); Switch(on, { on = it }) }
        Button({ App.ble.setAlarm(0, h, m, on) }, Modifier.fillMaxWidth()) { Text("Send to watch") }
    }
}

@Composable fun SettingsScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        Button({ ctx.startActivity(android.content.Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }, Modifier.fillMaxWidth()) { Text("Enable message push (notification access)") }
        Button({ App.ble.driver?.syncTime(App.ble) }, Modifier.fillMaxWidth()) { Text("Sync time") }
    }
}
