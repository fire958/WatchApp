package com.watchhub.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.*
import java.util.Calendar
import kotlin.math.*

val Orange = Color(0xFFFF7A1A)

/** Apple Watch Ultra jaisa premium animated dial (titanium bezel, orange accent, smooth seconds hand, battery ring). */
@Composable
fun UltraDial(battery: Int?, modifier: Modifier = Modifier) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); withFrameMillis { } } }
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.6f, 1f,
        infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "pulse")
    val tm = rememberTextMeasurer()

    Canvas(modifier.aspectRatio(0.84f)) {
        val c = Calendar.getInstance().apply { timeInMillis = now }
        val ms = c.get(Calendar.MILLISECOND); val s = c.get(Calendar.SECOND) + ms / 1000f
        val m = c.get(Calendar.MINUTE) + s / 60f; val h = (c.get(Calendar.HOUR) % 12) + m / 60f
        val center = Offset(size.width / 2, size.height / 2)
        val r = min(size.width * 0.5f, size.height * 0.5f)

        // Titanium case
        drawRoundRect(Brush.linearGradient(listOf(Color(0xFFB8BCC2), Color(0xFF5A5E66), Color(0xFFD9DCE0))),
            cornerRadius = CornerRadius(r * 0.55f), style = Fill)
        drawRoundRect(Color.Black, topLeft = Offset(size.width * 0.04f, size.height * 0.035f),
            size = Size(size.width * 0.92f, size.height * 0.93f), cornerRadius = CornerRadius(r * 0.5f))

        // Minute ticks (orange every 5)
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90).toFloat(); val big = i % 5 == 0
            val r1 = r * 0.82f; val r2 = r1 - if (big) r * 0.09f else r * 0.04f
            drawLine(if (big) Color.White else Color(0xFF777777),
                center + Offset(cos(a), sin(a)) * r1, center + Offset(cos(a), sin(a)) * r2, if (big) 5f else 2f)
        }
        // 12 marker (orange)
        drawLine(Orange, center + Offset(0f, -r * 0.82f), center + Offset(0f, -r * 0.70f), 9f, StrokeCap.Round)

        // Numbers
        for (n in listOf(3, 6, 9, 12)) {
            val a = Math.toRadians(n * 30.0 - 90).toFloat()
            val t = tm.measure(AnnotatedString(n.toString()), TextStyle(Color.White, (r * 0.09f).toSp(), FontWeight.Bold))
            val p = center + Offset(cos(a), sin(a)) * (r * 0.58f)
            drawText(t, topLeft = p - Offset(t.size.width / 2f, t.size.height / 2f))
        }
        // Battery ring
        val pct = (battery ?: 0) / 100f
        drawArc(Color(0xFF222222), 0f, 360f, false, center - Offset(r * 0.33f, r * 0.33f), Size(r * 0.66f, r * 0.66f), style = Stroke(10f))
        drawArc(if ((battery ?: 100) < 20) Color.Red else Color(0xFF34C759), -90f, 360f * pct, false,
            center - Offset(r * 0.33f, r * 0.33f), Size(r * 0.66f, r * 0.66f), style = Stroke(10f, cap = StrokeCap.Round))
        val bt = tm.measure(AnnotatedString(battery?.let { "$it%" } ?: "--"), TextStyle(Color.White, (r * 0.08f).toSp(), FontWeight.SemiBold))
        drawText(bt, topLeft = center + Offset(-bt.size.width / 2f, r * 0.12f))

        // Hands
        fun hand(angle: Float, len: Float, w: Float, col: Color) = rotate(angle, center) {
            drawLine(col, center + Offset(0f, r * 0.08f), center + Offset(0f, -len), w, StrokeCap.Round) }
        hand(h * 30f, r * 0.45f, 12f, Color.White)
        hand(m * 6f, r * 0.68f, 9f, Color.White)
        hand(s * 6f, r * 0.76f, 4f, Orange)          // smooth sweeping seconds
        drawCircle(Orange, 12f * pulse + 4f, center); drawCircle(Color.Black, 5f, center)
    }
}
